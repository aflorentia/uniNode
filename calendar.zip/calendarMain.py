import numpy as np
import pandas as pd
from tkinter import *
from PIL import ImageTk, Image
from openpyxl.workbook import Workbook
from tkcalendar import *
from openpyxl import load_workbook
from tkinter.font import Font
from tkinter import ttk

def addEvent():
        
    screen1 = Tk()
    screen1.title("Select Courses")
    screen1.minsize(600,600)
    screen1.maxsize(600 , 600)

    main_frame =Frame(screen1)
    main_frame.pack(fill=BOTH, expand=1)

    my_canvas= Canvas(main_frame)
    my_canvas.pack(side=LEFT, fill=BOTH , expand=1)

    my_scrollbar = ttk.Scrollbar(main_frame, orient= VERTICAL , command= my_canvas.yview)
    my_scrollbar.pack(side= RIGHT ,fill=Y)

    my_canvas.configure(yscrollcommand = my_scrollbar.set)
    my_canvas.bind('<Configure>', lambda e: my_canvas.configure(scrollregion= my_canvas.bbox("all")))

    second_frame= Frame(my_canvas)

    my_canvas.create_window((250,300),window=second_frame )

    wb = Workbook()
    wb =load_workbook('/Users/emmaeconomopoulou/Desktop/gui/events.xlsx')
    ws = wb.active
    cola= ws['A']
    colb= ws['B']
    colc= ws['C']
    label = Label(second_frame, text="")
    label.pack(padx=150)
    list= ''
    for cell in ws.iter_rows(min_row=1, max_row=7,min_col=1,max_col=3,values_only=True ):
        list= f'{list +"●  " + str(cell) }\n'
        list = list.replace('(', '')
        list = list.replace(')', '')
        list = list.replace('\'', '')
        label.config(text=list)
        
    def add_event():
        pass

    my_img=ImageTk.PhotoImage(Image.open("/Users/emmaeconomopoulou/Desktop/gui/logo.png"))
    my_label=Label(image=my_img)
    my_label.place(x=150, y=0)


    add_event_btn= Button(screen1 ,text= "Add Event",width = 8 ,height = 2 ,fg ="#800000", command = add_event)
    add_event_btn.place(x=250, y=150)

    button_quit= Button(screen1 ,text= "OK",width = 8 ,height = 2 ,fg ="#800000", command = screen1.quit)
    button_quit.place(x= 500, y=550)

    screen1.mainloop()


def selectCourses():   

    screen1 = Tk()
    screen1.title("Select Courses")
    screen1.minsize(600,600)

    main_frame =Frame(screen1)
    main_frame.pack(fill=BOTH, expand=1)

    my_canvas= Canvas(main_frame)
    my_canvas.pack(side=LEFT, fill=BOTH , expand=1)

    my_scrollbar = ttk.Scrollbar(main_frame, orient= VERTICAL , command= my_canvas.yview)
    my_scrollbar.pack(side= RIGHT ,fill=Y)

    my_canvas.configure(yscrollcommand = my_scrollbar.set)
    my_canvas.bind('<Configure>', lambda e: my_canvas.configure(scrollregion= my_canvas.bbox("all")))

    second_frame= Frame(my_canvas)

    my_canvas.create_window((0,0),window=second_frame, anchor= "nw")

    wb = Workbook()
    wb =load_workbook('/Users/emmaeconomopoulou/Desktop/gui/courses.xlsx')
    ws = wb.active
    cola= ws['A']

    list1=''
    checkbox_vars = {}
    values=[0]*116
    def check():
        for i,cell in enumerate(cola):
            values[i]=(checkbox_vars[cell].get())
    for cell in cola:
        var=IntVar()
        list1= Checkbutton(second_frame, text= str(cell.value) ,variable=var, command = check)
        list1.pack()
        checkbox_vars[cell] = var

    button_quit1= Button(screen1 ,text= "OK",width = 8 ,height = 2 ,fg ="#800000", command =screen1.quit)
    button_quit1.place(x= 500, y=550)
    
    screen1.mainloop()

def selectDate():
    myDate=myCal.get_date()
    label_date= Label(screen,fg ="#800000", text="")
    label_date.place(x=155, y= 200)
    label_date.config(text=myDate)
    events= Button(screen, text= "Events",width = 5 ,height = 1 ,fg ="#800000", command =showEvents(myDate))
    events.place(x=220, y =202)

def showEvents(dat1):
    dat1 = dat1.replace('/', '.')
    screen1 = Tk()
    screen1.title("Event List")
    screen1.minsize(600,600)
    screen1.maxsize(600 , 600)


    wb = Workbook()
    wb =load_workbook('/Users/emmaeconomopoulou/Desktop/gui/events.xlsx')
    ws = wb.active

    cola= ws['A']
    colb= ws['B']
    colc= ws['C']
    label = Label(screen1, text="")
    label.pack(padx=150)
    list= ''

    df = pd.read_excel('/Users/emmaeconomopoulou/Desktop/gui/events.xls', index_col=None , header=None )
    for row in range(0, df.shape[0]):
        if dat1==df.loc[row][1]:
            msg = str(df.loc[row])
            label.config(text=msg)
        else:
            msg = "You are free to fly"
            label.config(text=msg)
    button_quitp= Button(screen1 ,text= "Ok",width = 18 ,height = 2 ,fg ="#800000", command = screen1.quit)
    button_quitp.place(x= 220, y=500)


screen = Tk()
screen.minsize(600 , 600)
screen.maxsize(600 , 600)
screen.title("UniNode")
screen.iconbitmap(" /Users/emmaeconomopoulou/Desktop/gui/logo.ico")
screen.configure(background = "white")





my_img=ImageTk.PhotoImage(Image.open("/Users/emmaeconomopoulou/Desktop/gui/logo.png"))
my_label=Label(image=my_img)
my_label.pack()



myCal= Calendar (screen, setmode = 'day', date_pattern ='d/m/yy')
myCal.place(x =70 , y = 250 )


custFont = Font(
    family = "Helvetica",
    size = 24,
    weight = "bold"
)

title= Label (text="Student Calendar", font = custFont, fg =  "#800000")
title.place(x=197, y=130)

openCal = Button(screen, text= "Select Courses",width = 18 ,height = 2 ,fg ="#800000", command = selectCourses)
openCal.place(x=380, y =270)

myDate= Button(screen, text= "Select Date",width = 8 ,height = 2 ,fg ="#800000", command = selectDate)
myDate.place(x=140, y =430)

label_date= Label(screen,fg ="#800000", text="")
label_date.place(x=155, y= 200)

openCal1 = Button(screen, text= "Add Event",width = 18 ,height = 2 ,fg ="#800000", command = addEvent)
openCal1.place(x=380, y =360)

button_quit= Button(screen ,text= "Exit Program",width = 18 ,height = 2 ,fg ="#800000", command = screen.quit)
button_quit.place(x= 220, y=500)


screen.mainloop()